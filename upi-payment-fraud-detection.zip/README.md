# UPI Payment Fraud Detection

A machine learning project to detect fraudulent transactions in UPI-based digital payment systems. The model is trained on a synthetic dataset and uses supervised learning techniques to identify potentially malicious or suspicious behavior in real-time.

## Features
- Preprocessing of transaction data
- Fraud classification using machine learning (e.g., Random Forest, Logistic Regression)
- Evaluation metrics: Accuracy, Precision, Recall, F1-Score
- Sample visualizations and confusion matrix

## Getting Started
```bash
pip install -r requirements.txt
python scripts/train_model.py
python scripts/predict.py
```
