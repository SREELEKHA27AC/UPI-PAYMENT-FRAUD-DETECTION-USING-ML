import pandas as pd
from sklearn.ensemble import RandomForestClassifier

# Dummy prediction script
df = pd.DataFrame({'amount': [5000]})
model = RandomForestClassifier()
model.fit(df[['amount']], [0])  # Dummy training
print("Prediction:", model.predict(df[['amount']]))
